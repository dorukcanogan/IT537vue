<template>
  <div class="footer">
      <br>
      <br>
      <b>İletişim:</b> <a href="dcanogan@gmail.com"> dcanogan@gmail.com</a>
      <br>
      <br>
      © 2021 Copyright:
      <span> Doruk Can Ogan</span>
    </div>
</template>

<script>

  export default {
    name: 'Footer',
    
    }
  
</script>


<style>
   .footer{
  margin-top:3%;
  background-color: rgb(255, 199, 78);
  color:white;
}
</style>